
/**
 * Enumeration class ShiftType - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public enum ShiftType
{
    NIGHT,
    DAY
}
